*************************************
Elman Recurrent network (newelm)
*************************************

Use  :py:func:`neurolab.net.newelm`


.. literalinclude:: ../../example/newff.py

:Result:
	.. image:: _static/newelm.png
