﻿******************************************
Feed Forward Multilayer Perceptron (newff)
******************************************

Use  :py:func:`neurolab.net.newff`


.. literalinclude:: ../../example/newff.py

:Result:
	.. image:: _static/ff_sin.png
