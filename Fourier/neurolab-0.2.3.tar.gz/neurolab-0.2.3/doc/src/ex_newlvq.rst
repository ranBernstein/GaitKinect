﻿*************************************
Learning Vector Quantization (newlvq)
*************************************

Use  :py:func:`neurolab.net.newlvq`

.. literalinclude:: ../../example/newlvq.py

:Result:
	.. image:: _static/newlvq.png
