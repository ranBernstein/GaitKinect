*******
Install
*******

Install *neurolab* using setuptools/distribute::

    easy_install neurolab

Or pip::

    pip install neurolab

Or, if you don't have setuptools/distribute installed, 
use the download `link <http://code.google.com/p/neurolab/downloads/list>`_ 
at right to download the source package, 
and install it in the normal fashion: Ungzip and untar the source package, 
cd to the new directory, and::

    python setup.py install

