﻿***********************************
Hopfield Recurrent network (newhop)
***********************************

Use  :py:func:`neurolab.net.newhop`, :py:func:`neurolab.tool.simhop`


.. literalinclude:: ../../example/newhop.py

:Result:

::

    Test on train samples:
    N True Sim. steps 1
    E True Sim. steps 1
    R True Sim. steps 1
    O True Sim. steps 1

    Test on defaced N:
    True Sim. steps 2
